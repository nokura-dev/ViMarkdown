$ErrorActionPreference = 'Stop'
$target = Join-Path $env:LOCALAPPDATA 'Programs/ViMarkdown'
New-Item -ItemType Directory -Force $target | Out-Null
Copy-Item "$PSScriptRoot/publish/*" $target -Recurse -Force
$shell = New-Object -ComObject WScript.Shell
$link = $shell.CreateShortcut((Join-Path ([Environment]::GetFolderPath('Programs')) 'ViMarkdown.lnk'))
$link.TargetPath = Join-Path $target 'ViMarkdown.exe'
$link.Save()
